# 1. 项目架构和前言

## 1.1. 项目框架建立

### 1.1.1. 架构图和启动类

**项目架构**

<img src="./xy-club流程记录.assets/image-20240312203803160.png" alt="image-20240312203803160" style="zoom: 67%;" />

**包的划分基本如下，其中 `application` 模块，内嵌三个子模块，符合我们的项目架构。**

先建立启动类。

<img src="./xy-club流程记录.assets/image-20240312203645943.png" alt="image-20240312203645943" style="zoom:50%;" />

然后集成 `springmvc` ，按照架构肯定是需要集成到 `apllication` 模块内的 `controller` 子模块。引入 `maven` 依赖，即 `spring-boot-web-starter`，并建立第一个 `Controller`。

但这里因为是一个微服务架构，启动器模块和应用模块不是一个包下，所以这里采用 `maven` 导入的方式将 应用模块导入。

注意这里需要把具体的子模块写入，写外层的 `application` 访问还是 404。

```java
        <dependency>
            <groupId>com.fanxy</groupId>
            <artifactId>xy-club-subject-application-controller</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>
```



### 1.1.2. 数据库和基础设施层相关

接着将基础设施层的代码进行添加，首当其冲的就是数据库相关的。

```xml
        <!-- jdbcStarter -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-jdbc</artifactId>
        </dependency>
        <!-- druid连接池 -->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid-spring-boot-starter</artifactId>
            <version>1.1.22</version>
        </dependency>
        <!-- mysql -->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.22</version>
        </dependency>
        <!-- mybatis-plus -->
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-boot-starter</artifactId>
            <version>3.4.0</version>
        </dependency>
```



同时将数据库表建立，通过 `mybatis-X` 生成关于题目分类表的代码

![image-20240317204912767](./xy-club流程记录.assets/image-20240317204912767.png)



然后在 `starter` 模块 中引入基础设施层模块，并在启动类上写入扫描 `mapper` 文件的注解，由此判断是否完成对模块的引入。

```xml
        <dependency>
            <groupId>com.fanxy</groupId>
            <artifactId>xy-club-subject-infra</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>
```

```java
@SpringBootApplication
@ComponentScan("com.fanxy")
@MapperScan("com.fanxy.**.mapper")
public class SubjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(SubjectApplication.class);
    }
}
```



然后更新配置文件，关于数据库相关的内容。

```yaml
spring:
  # TODO: 数据库【MySQL】 配置
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    username: root
    password: 123456
    url: jdbc:mysql://localhost:3306/xy-club?serverTimezone=Asia/Shanghai&useUnicode=true&characterEncoding=utf8&useSSL=false
    type: com.alibaba.druid.pool.DruidDataSource
    druid:
      initial-size: 20
      min-idle: 20
      max-active: 100
      max-wait: 60000
      stat-view-servlet:
        enabled: true
        url-pattern: /druid/*
        login-username: admin
        login-password: 123456
      filter:
        stat:
          enabled: true
          slow-sql-millis: 2000
          log-slow-sql: true
        wall:
          enabled: true
        config:
          enabled: true
```



为了验证是否完成对基础设施层的数据库部分完成依赖，我们直接在应用层的 `controller` 模块之前的测试代码中，首先在 `maven` 依赖基础设施层，然后在测试的 `controller` 随便进行一条数据的查询。



```java
@RestController
public class SubjectController {

    @Resource
    SubjectCategoryService subjectCategoryService;

    @GetMapping("/test")
    public String test() {
        SubjectCategory subjectCategory = subjectCategoryService.getById(1L);
        return subjectCategory.getCategoryName();
    }
}
```

![image-20240317212712809](./xy-club流程记录.assets/image-20240317212712809.png)

测试虽然成功，但是此时配置文件的密码是通过明文配置的，我们肯定不希望密码明文写在配置文件，因为使用的 `druid连接池`，所以当然可以借助它的能力，我们在基础设施层建立 `utils` 包，并写入加密解密的方法，其实本质是 `Druid` 自带的包的能力，只是进行了封装，我们通过 `main` 方法，生成对应的公私钥，并把本身数据库密码根据公钥加密，得到的加密串这些复制，改写启动类的 `yaml` 配置文件，即可完成非明文记录数据库密码。

```java
public class DruidEncryptUtil {

    private static String privateKey;

    private static String publicKey;

    static {
        try {
            String [] keyPair = ConfigTools.genKeyPair(512);
            privateKey = keyPair[0];
            System.out.println("privateKey : " + privateKey);
            publicKey = keyPair[1];
            System.out.println("publicKey : " + publicKey);
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            throw new RuntimeException(e);
        }
    }

    public static String encrypt(String plainText) throws Exception {
        String encryptedText = ConfigTools.encrypt(privateKey, plainText);
        System.out.println("encryptedText : " + encryptedText);
        return encryptedText;
    }

    public static String decrypt(String encryptedText) throws Exception {
        String decryptedText = ConfigTools.decrypt(publicKey, encryptedText);
        System.out.println("decryptedText : " + decryptedText);
        return decryptedText;
    }
    public static void main(String[] args) throws Exception {
        String encrypt = encrypt("123456");
        String decrypt = ConfigTools.decrypt("MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAINecJVPPQKc9BEm0YBsitT6aoB9OUQhzvtm6NFOEBvsoUHe4j2k2tdkXPUXmzhHQb0LSSUIUPj9J34p66gKGgMCAwEAAQ==",
                "MtLZQT5a7lM6YtWnBJ87FfYEg++WA9/NUAXR0/vCP1f/4UmJJsdsO4m+a2Qy41dszDeShdQcHARMdBxNiQ4cwA==");
        System.out.println(decrypt);
    }
}
```



### 1.1.3. Common层和Domain层基础建设

在 `common层` 引如 `lombok` 和 `mapstruct` ， 同时让 `infra层` 的 `maven` 引如 `common层` ，这时就可以在基础设施层的之前的通过 `mybatis-X` 生成的 **学科分类类** 写入 `@Data` 注解，把生成的 `get` `set` 方法删除，使得代码整洁。

接着我们可以写真正的领域相关的 `Service` 层了，我们在 `domain层` 建立 `SubjectCategoryDomainService` 接口，并建立实现类和所在包，同时这里我们操作的实体类对象，可以复制 `infra层` 的 `SubjectCategory类` ， 命名为  `SubjectCategoryBO` ，而再建立 `convert` 包，用引入的 `mastruct` 创建 `BO` 和 `Entity` 的转化器。

![image-20240323191043409](./xy-club流程记录.assets/image-20240323191043409.png)

```java
// 注意这里的 Mapper 是 mapstruct 的
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SubjectCategoryConverter {

    SubjectCategoryConverter INSTANCE = Mappers.getMapper(SubjectCategoryConverter.class);

    SubjectCategory convertBoToCategory(SubjectCategoryBO subjectCategoryBO);
}
```

```java
public class SubjectCategoryDomainServiceImpl implements SubjectCategoryDomainService {

    @Resource
    SubjectCategoryService subjectCategoryService;


    @Override
    public void add(SubjectCategoryBO subjectCategoryBO) {
        SubjectCategory subjectCategory = SubjectCategoryConverter.INSTANCE
                .convertBoToCategory(subjectCategoryBO);
        subjectCategoryService.save(subjectCategory);
    }
}
```



### 1.1.4. 应用层建立Controller

让 `Application-controller层` 导入 `Domain层` ，因为 `BO` 是业务层，也就是领域层交互的实体单位，而到了应用层，使用的实体单位是`DTO`， 所以需要如法炮制上面的机制，写 `SubjectCategoryDTOConverter` ，并开始写 `SubjectCategoryController` 。

这里 应用层显然需要依赖 `Domain层` ， 同时到了此步骤，需要给前端返回结果了，故我们肯定需要封装一个返回结果类，用于和前端进行数据交互，从而完成闭环，故需要写 `Result类`，当然这个类肯定要写在公共的 `Common模块`。

 



















